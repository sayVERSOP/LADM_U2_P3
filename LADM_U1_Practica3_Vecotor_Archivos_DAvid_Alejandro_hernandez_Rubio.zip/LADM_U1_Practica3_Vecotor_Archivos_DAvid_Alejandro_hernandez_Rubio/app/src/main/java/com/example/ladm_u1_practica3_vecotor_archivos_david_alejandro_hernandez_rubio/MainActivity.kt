package com.example.ladm_u1_practica3_vecotor_archivos_david_alejandro_hernandez_rubio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import java.io.*

class MainActivity : AppCompatActivity() {
var arreglo = arrayOf(0,1,2,3,4,5,6,7,8,9)
    internal val eddi2 = "info.txt"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }




    fun guardarArchivo(v: View) {
        val data = editText2.getText().toString() .toString()

        try {
            val archivo = OutputStreamWriter(
                openFileOutput(eddi2, MODE_PRIVATE)
            )

            archivo.write(data)
            archivo.close()
            limpiar()

        } catch (e: Exception) {
        }
        button2.setOnClickListener {

        }

    }

    fun guardarArchivoSD(v: View) {
        val data = editText2.getText().toString()

            val rutaSD = Environment.getExternalStorageDirectory()
            val datosArchivo = File(rutaSD.absolutePath, "archivo.txt")
            val archivo = OutputStreamWriter(
                FileOutputStream(datosArchivo)
            )

            archivo.write(data)
            archivo.close()
            limpiar()


        }

    }



    fun limpiarCampos(v: View) {
        limpiar()
    }

    private fun limpiar() {
    }



